const localtunnel = require('localtunnel');

const PORT = 3000;
const SUBDOMAIN = 'predator-prey-stability';

async function startTunnel() {
  try {
    const tunnel = await localtunnel({ port: PORT, subdomain: SUBDOMAIN });
    console.log(`\n========================================`);
    console.log(`Live Public Tunnel URL: ${tunnel.url}`);
    console.log(`========================================\n`);

    tunnel.on('close', () => {
      console.log('Tunnel closed. Reconnecting in 3 seconds...');
      setTimeout(startTunnel, 3000);
    });

    tunnel.on('error', (err) => {
      console.error('Tunnel error:', err);
      tunnel.close();
    });
  } catch (err) {
    console.error('Failed to establish tunnel:', err);
    setTimeout(startTunnel, 3000);
  }
}

startTunnel();
