const MathEngine = require('./js/math-engine.js');

console.log('--- Testing MathEngine ---');

// Test 1: Classic Lotka-Volterra
const lvParams = { alpha: 1.0, beta: 0.1, gamma: 1.5, delta: 0.075 };
const lvEq = MathEngine.findEquilibria('lotka_volterra', lvParams);
console.log('Lotka-Volterra Equilibria:', lvEq);

const lvCoex = lvEq.find(e => e.id === 'coexistence');
const lvJ = MathEngine.computeJacobian('lotka_volterra', lvParams, lvCoex.x, lvCoex.y);
console.log('Lotka-Volterra Jacobian at Coexistence:', lvJ);

const lvStability = MathEngine.analyzeStability(lvJ);
console.log('Lotka-Volterra Stability:', {
  classification: lvStability.classification,
  category: lvStability.category,
  trace: lvStability.trace,
  det: lvStability.det,
  lambda1: lvStability.lambda1,
  lambda2: lvStability.lambda2
});

// Test 2: Logistic Model
const logParams = { r: 1.2, K: 35.0, beta: 0.1, gamma: 1.0, delta: 0.05 };
const logEq = MathEngine.findEquilibria('logistic', logParams);
console.log('Logistic Equilibria:', logEq);
const logCoex = logEq.find(e => e.id === 'coexistence');
const logJ = MathEngine.computeJacobian('logistic', logParams, logCoex.x, logCoex.y);
const logStability = MathEngine.analyzeStability(logJ);
console.log('Logistic Stability:', {
  classification: logStability.classification,
  category: logStability.category,
  trace: logStability.trace,
  det: logStability.det,
  lambda1: logStability.lambda1,
  lambda2: logStability.lambda2
});

// Test 3: Rosenzweig-MacArthur Model
const rmParams = { r: 1.5, K: 40.0, a: 0.12, h: 0.1, e: 0.25, d: 0.4 };
const rmEq = MathEngine.findEquilibria('rosenzweig', rmParams);
console.log('Rosenzweig Equilibria:', rmEq);
const rmCoex = rmEq.find(e => e.id === 'coexistence');
const rmJ = MathEngine.computeJacobian('rosenzweig', rmParams, rmCoex.x, rmCoex.y);
const rmStability = MathEngine.analyzeStability(rmJ);
console.log('Rosenzweig Stability:', {
  classification: rmStability.classification,
  category: rmStability.category,
  trace: rmStability.trace,
  det: rmStability.det,
  lambda1: rmStability.lambda1,
  lambda2: rmStability.lambda2
});

// Test 4: RK4 Simulation
const traj = MathEngine.simulateRK4('lotka_volterra', lvParams, 20, 10, 5, 0.1);
console.log(`RK4 simulation produced ${traj.length} points.`);
console.log('First point:', traj[0]);
console.log('Last point:', traj[traj.length - 1]);

console.log('ALL MATH TESTS COMPLETED SUCCESSFULLY!');
